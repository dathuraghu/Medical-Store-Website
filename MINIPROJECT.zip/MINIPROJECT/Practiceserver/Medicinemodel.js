import mongoose, { Schema } from 'mongoose';

const medicineSchema = new Schema({
   type:String,
   mname:String,
   price:Number,
   quantity:Number
});

export const  Medicine = mongoose.model('medicine',medicineSchema);