export const ERROR_MESSAGE = "Something Went Wrong";
export const INSERT_SUCCESS = "Data inserted Successfully";
export const MEDICINE_NOT_FOUND = "Data Not Found";
export const UPDATE_SUCCESS = " Data Updated";
export const DELETE_SUCCESS = "Data Deleted Successfully";