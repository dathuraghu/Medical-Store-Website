import express, { response } from 'express';
import mongoose from 'mongoose';
import {Medicine} from './Medicinemodel.js';
import { Admin } from './Adminmodel.js';
import {ERROR_MESSAGE, INSERT_SUCCESS, MEDICINE_NOT_FOUND, UPDATE_SUCCESS, DELETE_SUCCESS} from './constants.js';
import StatusCodes from 'http-status-codes';
import cors from 'cors';
import bcrypt from 'bcrypt';         //for password encryption
import jwt from 'jsonwebtoken';

function verifyToken(request,response,next){
        const header = request.get('Authorization');
         if(header){
            const token =  header.split(" ")[1];
             jwt.verify(token,"secret1234",(error,payload)=>{
                  if (error) {
                    response.status(StatusCodes.UNAUTHORIZED).send({message:"Invalid Token"});
                  } else {
                     next();
                  }
             });
         }
        else{
                response.status(StatusCodes.UNAUTHORIZED).send({message:"Please login first"});
           
        }

}

const app = express();
app.use(cors());
app.use(express.json());

const connectDb = async()=>{
     try{
        await mongoose.connect("mongodb://127.0.0.1:27017/jewelrydb");
        console.log("Database connection created");
     }catch(error){
        console.log(error);
     }
}

app.post("/admin", async(request,response) =>{
    try {
        const reqData = request.body;
        reqData['password'] = bcrypt.hashSync(reqData.password,10);  //10 is no of rounds
        const admin = new Admin(reqData);
        await admin.save();
        response.status(StatusCodes.CREATED).send({message:INSERT_SUCCESS});
    } catch (error) {
        console.log(error);
        response.status(StatusCodes.INTERNAL_SERVER_ERROR).send({message:ERROR_MESSAGE});
    }
});



app.post("/admin/login",async(request,response)=>{
       try{
         const admin = await Admin.findOne({email:request.body.email});
         if(admin){
            if(bcrypt.compareSync(request.body.password,admin.password)){  //plainpass,encryptedpass
            const token = jwt.sign({adminEmail:admin.email},"secret1234");      //generate token
                response.status(StatusCodes.OK).send({message:"Login Successful",token:token});

            }else{
                console.log("in else");
                response.status(StatusCodes.BAD_REQUEST).send({message:"Invalid Email or Password"});
            }
         }
       }catch(error){
        console.log("in catch");
        response.status(StatusCodes.INTERNAL_SERVER_ERROR).send({message:ERROR_MESSAGE});
       }
});



app.get("/medicine",verifyToken,async(request,response)=>{
      try{
              const data = await Medicine.find();
              response.send({medicine:data});  
            }
            catch(error){
        response.status(StatusCodes.INTERNAL_SERVER_ERROR).send({mesagge:ERROR_MESSAGE});
      }
})

app.post("/medicine",verifyToken,async (request,response)=>{
    try {
        const reqData = request.body;
        const medicine = new Medicine(reqData);
        await medicine.save();
        response.send({message:INSERT_SUCCESS});
    } catch (error) {
        console.log(error);
    }
});

app.get("/medicine/:mname",verifyToken,async(request,response)=>{
    try{ const medicine = await Medicine.findOne({mname:request.params.mname});
     if(medicine == null){
        response.status(404).send({message:MEDICINE_NOT_FOUND});
     }else{
          response.send({medicine:medicine});
     }
    }catch(error){
        response.status(500).send({message:ERROR_MESSAGE});
    }
})

app.delete("/medicine/:mname",verifyToken,async(request,response)=>{
    try {
        await Medicine.deleteOne({mname:request.params.mname});
        response.send({message:DELETE_SUCCESS});
    } catch (error) {
        response.status(500).send({message:ERROR_MESSAGE});
    }
});


app.put("/medicine/:mname",verifyToken,async(request,response)=>{
    try {
        await Medicine.updateOne({mname:request.params.mname},request.body);
        response.send({message:UPDATE_SUCCESS});
    } catch (error) {
        response.status(500).send({message:ERROR_MESSAGE});
    }
});


app.listen(5202,()=>{
    console.log("Server has started on 5202");
    connectDb();
})