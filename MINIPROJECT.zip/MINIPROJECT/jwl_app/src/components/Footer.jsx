import './cssfiles/Footerstyle.css';

export function Footer() {
   return(
   
  <div className="Footer">
    <div className="container bg-grey">
      <div className="row">
        <div className="col-md-3 col-lg-5 col-12">
        <h4>CarePoint Pharmacy</h4>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis a dicta eligendi quod excepturi harum nam. Illo quo quos obcaecati et iure, corporis nobis optio minima debitis doloribus, quam temporibus?</p>
        <div className="footer-icons">
        <i class="fa-brands fa-facebook"></i>  
        <i class="fa-brands fa-x-twitter"></i>
        <i class="fa-brands fa-instagram"></i>
        <i class="fa-brands fa-linkedin"></i>
        </div>
        </div>
        <div className="col-md-3 col-lg-3 col-12">
        <h4>Quick Links</h4>
        <ul>
           <li className="nav-item">
            <a className="nav-link" href="/">About Us</a>
            </li> 
            <li className="nav-item">
            <a className="nav-link" href="/">Contact Us</a>
            </li> 
            <li className="nav-item">
            <a className="nav-link" href="/">Special Services</a>
            </li> 
            <li className="nav-item">
            <a className="nav-link" href="/">Pata nahi</a>
            </li> 
        </ul>
        </div>
         <div className="col-md-3 col-lg-4 col-12 ">
            <h4>Contact Info</h4>
            <p> <i class="fa-solid fa-phone-volume"></i> +91 7343483498</p>
            <p> <i class="fa-solid fa-envelope"></i>carepointpharmacy@gmail.com</p>
            <p> <i class="fa-solid fa-location-dot"></i> Kharghar,Navi Mumbai</p>
        </div>
      </div>
    </div>
  </div>
 
  );
}
