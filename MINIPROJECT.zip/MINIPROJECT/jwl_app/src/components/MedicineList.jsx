import { Container,Button,Modal } from "react-bootstrap";
import { Header } from './Header';
import { useEffect, useState} from "react";
import { deleteMedicine, getMedicine,updateMedicine } from '../services/MedicineServices';
import { Table } from 'react-bootstrap';
import { useNavigate } from "react-router-dom";       //this will give us navigate function
import { Navigationbar } from "./Navigationbar";


export function MedicineList(){
    const [medicine,setMedicine] = useState([]);
    const [showDialog, setShowDialog] = useState(false);
    const [selectedmname, setSelectedMname] = useState("");
    const navigate = useNavigate();

    const openModalDialog = () =>{
         setShowDialog(true);
    }

    const closeModalDialog = () =>{
        setShowDialog(false);
   }

    async function fetchMedicineList(){
        try{
           const data = await getMedicine();
           setMedicine(data.medicine);
        }catch(error){
            console.log(error);
        }
    }

    useEffect(()=>{
        fetchMedicineList();   
    },[]);

    const handleDeleteClick = async() => {
          try{
           await deleteMedicine(selectedmname);
           fetchMedicineList();
           closeModalDialog();
          }catch(error){
            console.log(error);
          }
    }

    
    
      return(
        <><Navigationbar></Navigationbar>
      <Container>
        <Header text="List of all the Medicines"></Header>
        {medicine.length !== 0 ? 
        <Table className="mt-5">
         <thead>
            <tr>
                <th>Medicine Type</th>
                <th>Medicine Name</th>
                <th> Price </th>
                <th>Quantity</th>
            </tr>
         </thead>
         <tbody>
            {
                medicine.map((s)=>{
                    return(
                        <tr>
                            <td>{s.type}</td>
                            <td>{s.mname}</td>
                            <td>{s.price}</td>
                            <td>{s.quantity}</td>
                            <td>
                                <Button variant="danger"  onClick={()=>{
                                     openModalDialog(); 
                                     setSelectedMname(s.mname);
                                }} >Delete</Button>  &nbsp; &nbsp; &nbsp;
                                
                                <Button variant="primary" onClick={()=> {
                                      
                                        navigate(`/edit/${s.mname}`);
                                }}>Update </Button>
                            </td>
                        </tr>
                        
                    )
                })
            }
         </tbody>
        </Table> : <h2> No medicines available </h2> }
        <Modal show={showDialog} onHide={closeModalDialog}>
        <Modal.Header closeButton>
          <Modal.Title>Confirmation</Modal.Title>
        </Modal.Header>
        <Modal.Body>Do you really want to delete {selectedmname}?</Modal.Body>
        <Modal.Footer>
          <Button variant="success"  onClick = {() => {handleDeleteClick()}}>
          YES
          </Button>
          <Button variant="danger"  onClick = {closeModalDialog}>
           NO
          </Button>
        </Modal.Footer>
      </Modal>

     </Container>
     </>
      );
}