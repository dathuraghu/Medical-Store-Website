//SAME AS SIGN UP FORM BASS KUCH CHANGES HAI

import { Button, Col, Container, Form, Row,Alert } from "react-bootstrap";
import { Header } from "./Header";
import { useState,useEffect } from "react";
import { fetchMedicineByMname, updateMedicine } from "../services/MedicineServices";
import { useParams } from "react-router-dom";

export function MedicineEditForm() {
   const params = useParams();
    const [formData,setFormData]=useState({type:"",mname:"",price:"",quantity:""});
    const [isSubmitted,setSubmitted] = useState(false);

    const handleChange=(e)=>{
        setFormData({...formData,[e.target.name]:e.target.value});
    }
     
    

    const handleEdit = async(e) => {
           e.preventDefault();
           try{
            const result=await updateMedicine(formData,params.mname);
             setFormData({type:"",mname:"",price:"",quantity:""});
             setSubmitted(true);
             setTimeout(()=>{
                setSubmitted(false);
            },2500);
            console.log(result); 
           }catch(error){
                console.log(error);
           }
    }
// for EDIT fetch krlo mname ke through
    const populateMedicineState = async() => {
        try{
            const result = await fetchMedicineByMname(params.mname);
            setFormData(result.medicine);
        }catch(error){
            console.log(error);
        }
    }

    useEffect(()=>{
        populateMedicineState();
    },[]);

    return (
        <Container>
            <Header text="Update Medicine data here"></Header>

            <Form onSubmit={handleEdit}>
                <Row  className="justify-content-md-center">
                    <Col lg={4}>
                        <Form.Group className="mb-3">
                            <Form.Label>Medicine Type</Form.Label>
                            <Form.Control type="text" value={formData.type} placeholder="e.g.Tablets,Syrup ,etc" name="type"  onChange={handleChange} />    {/*YAHA PE CHANGE HAI, EVENT IS ONCHANGE, NORMLA FORM MAIN ONKEYUP THA AND ALSO VALUE KI FIELD CHANGE HAI HERE IT IS FORMDATA.FNAME, SAME FOR OTHER FIELDS*/}
                        </Form.Group>
                    </Col>
                </Row>
                <Row  className="justify-content-md-center">
                    <Col lg={4}>
                        <Form.Group className="mb-3">
                            <Form.Label>Medicine Name</Form.Label>
                            <Form.Control type="text" value={formData.mname} placeholder="Enter Name" name="mname"  onChange={handleChange}/>
                        </Form.Group>
                    </Col>
                </Row>
                <Row  className="justify-content-md-center">
                    <Col lg={4}>
                        <Form.Group className="mb-3">
                            <Form.Label>Price</Form.Label>
                            <Form.Control type="text" value={formData.price} placeholder="Enter Price" name="price" onChange={handleChange}/>
                        </Form.Group>
                    </Col>
                </Row>
                <Row  className="justify-content-md-center">
                    <Col lg={4}>
                        <Form.Group className="mb-3">
                            <Form.Label>Quantity</Form.Label>
                            <Form.Control type="text" value={formData.quantity} placeholder="Enter quauntiy" name="quantity" onChange={handleChange}/>
                        </Form.Group>
                    </Col>
                </Row>
                 
                <Row className="mt-3 justify-content-md-center" >
                    <Col lg={2}>
                        <Button variant="primary" type="submit">Update</Button>
                    </Col>

                </Row>
            </Form>
            <Row  className="justify-content-md-center">
                <Col lg={4}>
                   {
                    isSubmitted? <Alert variant="success">Wohoo,Your data is updated</Alert> : null
                   }
                </Col>
            </Row>
        </Container>
    );
}