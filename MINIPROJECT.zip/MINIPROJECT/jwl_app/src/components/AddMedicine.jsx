//jo student ka sign up form tha.....

import { Button, Col, Container, Form, Row,Alert } from "react-bootstrap";
import { Header } from "./Header";
import { useState } from "react";
import { saveMedicine } from "../services/MedicineServices";
import { Navigationbar } from "./Navigationbar";

export function AddMedicine() {
    const [formData,setFormData]=useState({type:"",mname:"",price:"",quantity:""});
    const [isSubmitted,setSubmitted] = useState(false);

    const handleChange=(e)=>{
        setFormData({...formData,[e.target.name]:e.target.value});
    }
     
    

    const handleSubmit = async(e) => {
           e.preventDefault();
           try{
            const result = await saveMedicine(formData);
            setFormData({type:"",mname:"",price:"",quantity:""});
            setSubmitted(true);
            setTimeout(()=>{
                setSubmitted(false);
            },2500);
           console.log(result.message);
           }catch(error){
                console.log(error);
           }
    }

    return (
        <>
        <Navigationbar/>
        <Container>
            <Header text="ADD YOUR MEDICINE DATA HERE"></Header>

            <Form onSubmit={handleSubmit}>
                <Row  className="justify-content-md-center">
                    <Col lg={4}>
                        <Form.Group className="mb-3">
                            <Form.Label>MEDICINE TYPE</Form.Label>
                            <Form.Control type="text" value={isSubmitted?formData.type:null} placeholder="e.g.Tablets"  name="type"  onKeyUp={handleChange} />
                        </Form.Group>
                    </Col>
                </Row>
                <Row  className="justify-content-md-center">
                    <Col lg={4}>
                        <Form.Group className="mb-3">
                            <Form.Label>MEDICINE NAME</Form.Label>
                            <Form.Control type="text" value={isSubmitted?formData.mname:null} placeholder="Enter Name" name="mname"  onKeyUp={handleChange}/>
                        </Form.Group>
                    </Col>
                </Row>
                <Row  className="justify-content-md-center">
                    <Col lg={4}>
                        <Form.Group className="mb-3">
                            <Form.Label>PRICE</Form.Label>
                            <Form.Control type="text" value={isSubmitted?formData.price:null} placeholder="Enter Phone" name="price" onKeyUp={handleChange}/>
                        </Form.Group>
                    </Col>
                </Row>
                <Row  className="justify-content-md-center">
                    <Col lg={4}>
                        <Form.Group className="mb-3">
                            <Form.Label>QUANTITY</Form.Label>
                            <Form.Control type="text" value={isSubmitted?formData.quantity:null} placeholder="Enter Quantity" name="quantity" onKeyUp={handleChange}/>
                        </Form.Group>
                    </Col>
                </Row>
             
                
                <Row className="mt-3 justify-content-md-center" >
                    <Col lg={2}>
                        <Button variant="primary" type="submit">Add Data</Button>
                    </Col>

                </Row>
            </Form>
            <Row  className="justify-content-md-center">
                <Col lg={4}>
                   {
                    isSubmitted? <Alert variant="success">Data is Added Successfully</Alert> : null
                   }
                </Col>
            </Row>
        </Container>
        </>
    );
}