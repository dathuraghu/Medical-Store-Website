import { Navigate } from "react-router-dom";
import { isAuthenticated } from "../util/TokenUtil";

export function RedirectIfLogIn(props){
    if (isAuthenticated()) {
        return <Navigate to="/"></Navigate>
    } else {
        return props.children;
    }
}