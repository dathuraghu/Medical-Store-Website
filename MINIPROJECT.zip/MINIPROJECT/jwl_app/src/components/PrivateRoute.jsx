import { isAuthenticated } from "../util/TokenUtil";
import { Navigate } from "react-router-dom";

export function PrivateRoute(props) {
  if (isAuthenticated()) {
    return props.children;
  } else {
    return <Navigate to="/"></Navigate>;
  }
}
