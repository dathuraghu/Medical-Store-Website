import Carousel from "react-bootstrap/Carousel";
import image1 from "../images/home1.png";
import image2 from "../images/home2.png";
import { Navigationbar } from "./Navigationbar";
import "./cssfiles/Homestyle.css";
import { Footer }  from "./Footer";

export function Home() {
  return (
    <>
    <Navigationbar/>
      <Carousel interval={850} fade>
        <Carousel.Item>
          <img className="d-block w-100" src={image1} alt="First slide" />

          <Carousel.Caption>
            <h3>WELCOME TO THE CAREPOINT PHARMACY!</h3>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img className="d-block w-100" src={image2} alt="First slide" />

          <Carousel.Caption>
            <h5>PLEASE LOGIN TO THE MANAGE THE STORE</h5>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>
      <Footer></Footer>
    </>

);
}