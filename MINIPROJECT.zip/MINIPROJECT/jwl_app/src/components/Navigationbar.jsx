import { Button } from 'react-bootstrap';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import {useNavigate} from 'react-router-dom';
import { LinkContainer } from 'react-router-bootstrap';
import {logout} from '../util/TokenUtil.js';
import "./cssfiles/Navigationstyle.css";


export function Navigationbar() {
  const navigate=useNavigate();
    const handleLogoutClick=()=>{
        logout();
        navigate("/");
    }
  return (
    
    <Navbar collapseOnSelect
    expand="md"
    sticky="top"
    className="bg-body-tertiary custom-navbar"
    bg="dark"
    data-bs-theme="dark">
      <Container>
        <Navbar.Brand>CAREPOINT</Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="me-auto">
            <LinkContainer to='/'> 
            <Nav.Link><i className="fas fa-home"></i>Home</Nav.Link>
            </LinkContainer>
            <LinkContainer to='/add-medicine'> 
            <Nav.Link><i class="fa-solid fa-cart-plus"></i>Add Medicine</Nav.Link>
            </LinkContainer>
            <LinkContainer to='/medicine-list'>
            <Nav.Link><i class ="fa-solid fa-list" />Medicine List</Nav.Link>
            </LinkContainer>
            <LinkContainer to='/login'>
            <Nav.Link><i class="fa-regular fa-user"></i>Login</Nav.Link>
            </LinkContainer>
          </Nav>
         <Button variant="primary"  className="btn btn-outline-success button"  onClick={handleLogoutClick}>Logout</Button>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}
