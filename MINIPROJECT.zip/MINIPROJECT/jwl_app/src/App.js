import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import {Home} from './components/Home';
import { AddMedicine } from './components/AddMedicine';
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { MedicineList } from './components/MedicineList';
import { MedicineEditForm } from './components/MedicineEditForm';
import {Login} from './components/Login';
import { PrivateRoute } from './components/PrivateRoute';
import { RedirectIfLogIn } from './components/RedirectIfLogIn';


function App() {
  return (
   <BrowserRouter>
     <Routes>
   

    <Route path="/" element={<Home/>}></Route>
    <Route path="/login" element={<Login/>}></Route>
    <Route path="/medicine-list" element={<PrivateRoute><MedicineList/></PrivateRoute>}></Route> 
     <Route path='/add-medicine' element={<PrivateRoute><AddMedicine/></PrivateRoute>}></Route>
    <Route path='/edit/:mname' element={<PrivateRoute><MedicineEditForm/></PrivateRoute>}> </Route> 
      






      </Routes>
   
   
   
   
    </BrowserRouter>
  );
}

export default App;
