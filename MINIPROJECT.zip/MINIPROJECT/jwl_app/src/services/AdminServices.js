import axios from "axios";


export async function login(credentials){
    console.log("adminservices");
    console.log(credentials);
    const response=await axios.post(`http://127.0.0.1:5202/admin/login`,credentials);
    console.log(response);
    return response.data;
}