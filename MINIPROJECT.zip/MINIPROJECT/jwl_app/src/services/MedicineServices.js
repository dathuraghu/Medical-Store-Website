import axios from 'axios';
import { BASE_URL } from './APIConstants';
import { getToken } from '../util/TokenUtil';

export async function getMedicine(){
      try{
         const response =  await axios.get(`${BASE_URL}/medicine`,{headers:{'Authorization':`Bearer ${getToken()}`}});
         return response.data;
      }
      catch(error){
        console.log(error);
      }
}

export async function saveMedicine(medicineData){
    try{
        const response = await axios.post(`${BASE_URL}/medicine`,medicineData,{headers:{'Authorization':`Bearer ${getToken()}`}});
        return response.data;
    }catch(error){
        console.log(error);
    }
}

export async function deleteMedicine(mname){
    try{
        const response = await axios.delete(`${BASE_URL}/medicine/${mname}`,{headers:{'Authorization':`Bearer ${getToken()}`}});
        return response.data;
    }catch(error){
        console.log(error);
    }
}

export async function fetchMedicineByMname(mname){
    try{
        const response = await axios.get(`${BASE_URL}/medicine/${mname}`,{headers:{'Authorization':`Bearer ${getToken()}`}});
        return response.data;
    }catch(error){
        console.log(error);
    }
}

export async function updateMedicine(updatedData,mname){
    try {
        const response=await axios.put(`${BASE_URL}/medicine/${mname}`,updatedData,{headers:{'Authorization':`Bearer ${getToken()}`}});
        return response.data;
    } catch (error) {
        console.log(error);
    }
}

